/**
 * Define the top-level Asana namespace.
 */
Asana = {};